///////////////////////////////////////////////////////////////////////
//
//            F L I G H T S A F E T Y   I N T E R N A T I O N A L
//
//   SIMULATOR       : Generic
//   JOB             : All
//   DEPARTMENT      : 65 - Navigation/Visual Software Group
//   MODULE NAME     : nav_iplib.cpp
//   DESCRIPTION     : IP file read/write support.
//   PACKAGE         : Navigation Library
//   RATE            : N/A - As Called
//   RELEASE         : 5.01
//   ORIGINATOR      : Terry Tyler
//   DATE            : March 01, 2001
//   ENGINEER        : Navigation/Visual Standards
//   SYSTEM          : FlightSafety SimNt
//
///////////////////////////////////////////////////////////////////////
//
//   Copyright 2001 FlightSafety International
//
//   The information contained herein is the property of
//   FlightSafety International Simulation Systems Division
//   and shall not be copied, in part or in whole, or disclosed
//   to others in any manner without the express written
//   authorization of the FlightSafety International Simulation
//   Systems Division.
//
///////////////////////////////////////////////////////////////////////
//
//          F L I G H T S A F E T Y   I N T E R N A T I O N A L
//              Simulation Systems Division
//              2700 North Hemlock Circle
//              Broken Arrow, Oklahoma 74012
//              (918) 259-4000  Fax: (918) 251-5597
///////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////
//
// Revision History:
//
// $Id: nav_iplib.cpp,v 5.1 2001/07/26 20:29:10 meyert Exp $
// $Log: nav_iplib.cpp,v $
// Revision 5.1  2001/07/26 20:29:10  meyert
// Initial release to Rev. 5.1
// (Updated initial module checkin, Rev. 5.0, with Rev. 3.18 comments)
//
// Revision 5.0  2001/06/13 19:56:02  terryt
// Initial Module Checkin.
//
// Revision 3.18
// 1.  Module(s):  nav_tcas.f, nav_tcas_aircraft_job#.f,nav_tcas_out.f,
//                 nav_tcas_threats.f
//     a. Surveillance of other A/C should not work during stby mode or
//        failure.
//     b. TCAS will not indicate FAIL in stby mode.
//     c. The NO BEARING DISPLAY requires Display Matrix to be set in
//        L132 even if label is NCD.
//     d. Widen window for auto-scenario availability. Modify cancel
//        threat logic so that auto-scenario a/c are not prematurely
//        removed.
// 2.  Module:  nav_acposn.f
//     Added new glass mountain logic.  Supports old glass mountain IOS
//     page, but now supports improved version as well.
// 3.  Module(s): nav_aircraft_job#.f, nav_wxr_pws.f
//     Added WXR_ON label to distinguish between ON and powered.  Also,
//     when WXR inop--there will be no PWS warning.
// 4.  Module(s): nav_dvm.f, nav_accent.inc
//     Added British accent support.  TACAN support.
// 5.  Module: nav_aircraft_job#.cfg &
//     a. nav_stby_cmps.f:  Fixed compass dynamics.
//     b. nav_repos.f:  Extensive rewrite of repos module--changes made
//                      to .cfg module for support.
//     c. nav_mref.f:  Check for single environment in .cfg module.
// 6.  Module: nav_lesson_plan.f
//     Added Malfunction Clear; cleaned up labels.
// 7.  Module: nav_geom.f
//     Extensive cleanup.
//
// Revision 3.17  2000/09/01 20:24:55  blake
// 1.  Module:  nav_repos.f
//     Added reposition to marker beacon capability under
//     the reposition to ident section.
// 2.  Module:  nav_dvm.f
//     Increased the ATIS visibility resolution for metric units.
//     Corrected the ILS station selection logic.
// 3.  Module:  nav_tcas_out.f
//     Corrected a comment line.
//
// Revision 1.1  1999/06/03 15:17:41  spencerd
// Initial revision
//
// Revision 1.5  1999/05/18 21:47:29  terryt
// fixed ramp file reference in the hold section.
//
// Revision 1.4  1999/05/18 17:06:11  terryt
// added gate capability to ramp data.
//
///////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////
// Man Page Support
///////////////////////////////////////////////////////////////////////
//.mp  .TH nav_iplib l FSI
//.mp  .SH NAME
//.mp  nav_iplib      \- FORTRAN interfaces to IP data files
//.mp
//.mp    n_ip_ramp_read   \- Read the ramp ip data file.
//.mp    n_ip_hold_read   \- Read the hold ip data file.
//.mp    n_ip_ramp_write  \- Write the ramp ip data file.
//.mp    n_ip_hold_write  \- Write the hold ip data file.
//.mp
//.mp
//.mp  .SH LIBRARY
//.mp
//.mp  Navigation/Visual Library (d65nav.a)
//.mp
//.mp
//.mp  .SH SYNOPSIS
//.mp
//.mp  void n_ip_ramp_read( inout:I*4:MaxIps,
//.mp                       out:I*4():AptIdnt, out:I*4():GateId,
//.mp                       out:R*8():IpLat, out:R*8():IpLon,
//.mp                       out:R*4():IpHdg, out:R*4():IpElv );
//.mp  void n_ip_hold_read( inout:I*4:MaxIps,
//.mp                       out:I*4():AptIdnt, out:I*4():RwyIdnt,
//.mp                       out:R*8():IpLat, out:R*8():IpLon,
//.mp                       out:R*4():IpHdg, out:R*4():IpElv );
//.mp
//.mp  void n_ip_ramp_write( in:I*4:MaxIps,
//.mp                        in:I*4():AptIdnt, in:I*4():GateId,
//.mp                        in:R*8():IpLat, in:R*8():IpLon,
//.mp                        in:R*4():IpHdg, in:R*4():IpElv );
//.mp  void n_ip_hold_write( in:I*4:MaxIps,
//.mp                        in:I*4():AptIdnt, in:I*4():RwyIdnt,
//.mp                        in:R*8():IpLat, in:R*8():IpLon,
//.mp                        in:R*4():IpHdg, in:R*4():IpElv );
//.mp
//.mp
//.mp  .SH PARAMETERS
//.mp
//.mp  MaxIps:  I*4 The maximum number of IP points to either read or write.
//.mp
//.mp  AptIdnt: I*4 The Airport Identifier, 4 characters, ASCII, left justified,
//.mp           with trailing blanks.
//.mp
//.mp  RwyIdnt: I*4 The Runway Identifier, 4 characters, ASCII, left justified,
//.mp           with trailing blanks.
//.mp
//.mp  GateId:  I*4 The Gate Identifier, 4 characters, ASCII, left justified,
//.mp           with trailing blanks.
//.mp
//.mp  IpLat:   R*8 The IP Latitude, in decimal degrees.
//.mp           (+/- 90.0, +=North)
//.mp
//.mp  IpLon:   R*8 The IP Longitude, in decimal degrees.
//.mp           (+/- 180.0, +=East)
//.mp
//.mp  IpHdg:   R*4 The IP True Heading, in decimal degrees.
//.mp           (+/- 180.0, 0=North, +=cloclwise)
//.mp
//.mp  IpElv:   R*4 The IP Elevation, in feet.
//.mp
//.mp  .SH DESCRIPTION
//.mp
//.mp  No description
//.mp
//.mp
//.mp  .SH RETURN VALUES
//.mp
//.mp  All parameters are returned through the argument lists.  Any parameter
//.mp  that is not in the data file is set to zeros.
//.mp
//.mp  .SH RELATED INFORMATION
//.mp
//.mp  References:  fsi_getcfg, fsi_logmsg_info
//.mp
//.mp  .SH NOTES:
//.mp
//.mp  No notes so far
//.mp
///////////////////////////////////////////////////////////////////////

#include "nav_iplib.h"

void n_ip_ramp_read( long *lpMaxInOut,       char    *szRampFileName,
                     long   **plaAptIdntOut, long   **plaGateIdOut,
                     double **pdaLatOut,     double **pdaLonOut,
                     float  **pfaHdgOut,     float  **pfaElvOut )
{
  FILE *hFp;

  static char  szBuffer[256]="";
  int i,k,iCnt;
  union { char sz[5];
    long l;
  } tAptIdnt;
  union { char sz[5];
    long l;
  } tGateIdnt;
  long lIdx;
  double dLat,dLon;
  float fHdg,fElv;

  long   *laAptIdntOut = *plaAptIdntOut;
  long   *laGateIdOut = *plaGateIdOut;
  double *daLatOut = *pdaLatOut;
  double *daLonOut = *pdaLonOut;
  float  *faHdgOut = *pfaHdgOut;
  float  *faElvOut = *pfaElvOut;

//
// Initialize the arrays to the default data.
//
  for ( i=0; i < *lpMaxInOut; i++ ) {
    laAptIdntOut[i] = BLANK_4;        // Set to 4 blanks.
    laGateIdOut[i]  = BLANK_4;
    daLatOut[i]     = 0.0;
    daLonOut[i]     = 0.0;
    faHdgOut[i]     = 0.0;
    faElvOut[i]     = 0.0;
  }

//
// Open the IP datafile for read purposes. First check to see if it needs
// to be checked out of RCS.  If the file open fails, set the number read
// to zero and return to the calling program.
//

  if ( ( hFp = fopen( szRampFileName, "r" ) ) == NULL ) {
    fprintf( stderr,"Cannot open Ramp IP data file '%s' with read permissions", szRampFileName );
    *lpMaxInOut = 0;
    return;
  }

//
//  Read the file into the local arrays. Limit the amount of data read
//  to the input variable *lpMaxInOut.
//
  iCnt = 0;

  while ( fgets( szBuffer, sizeof( szBuffer ), hFp ) && ( iCnt < *lpMaxInOut ) ) {
    if ( szBuffer[0] != '#' && strlen( szBuffer ) > 1 ) {   //Comment line?
      i = sscanf( szBuffer, " %d %s %s %lf %lf %f %f\n",
                  &lIdx, tAptIdnt.sz, tGateIdnt.sz, &dLat, &dLon, &fHdg, &fElv );

      if ( i == 7 ) {                            //Correct number of items?
        for ( k=strlen( tAptIdnt.sz ); k<4; k++ ) {
          tAptIdnt.sz[k] = ' ';
        }
        laAptIdntOut[iCnt] = tAptIdnt.l;

        for ( k=strlen( tGateIdnt.sz ); k<4; k++ ) {
          tGateIdnt.sz[k] = ' ';
        }
        if ( tGateIdnt.sz[0] != 0x40 ) {
          laGateIdOut[iCnt] = tGateIdnt.l;
        }

        daLatOut[iCnt] = dLat;
        daLonOut[iCnt] = dLon;
        faHdgOut[iCnt] = fHdg;
        faElvOut[iCnt] = fElv;

        iCnt++;
      }
      else {              //Data Mismatch
        fprintf( stderr,"Ramp Data Mismatch %s/%s.",
                 tAptIdnt.sz, tGateIdnt.sz );
      }
    }
    else {
//      fprintf(stderr,"Ramp Data Comment Line %10.10s.", szBuffer );
    }
  }
  fclose( hFp );

  fprintf( stderr,"%d Ramp ip's read.  %d ip's requested.", iCnt, *lpMaxInOut );

  *lpMaxInOut = iCnt;

  return;
}

void n_ip_hold_read( long *lpMaxInOut,        char    *szHoldFileName,
                     long   **plaAptIdntOut,  long   **plaRwyIdntOut,
                     double **pdaLatOut,      double **pdaLonOut,
                     float  **pfaHdgOut,      float  **pfaElvOut )
{
  FILE *hFp;
  static char  szBuffer[256]="";
  int  i,k,iCnt,iIdx;
  union { char sz[5];
    long l;
  } tAptIdnt;
  union { char sz[5];
    long l;
  } tRwyIdnt;
  double dLat,dLon;
  float fHdg,fElv;

  long   *laAptIdntOut = *plaAptIdntOut;
  long   *laRwyIdntOut = *plaRwyIdntOut;
  double *daLatOut = *pdaLatOut;
  double *daLonOut = *pdaLonOut;
  float  *faHdgOut = *pfaHdgOut;
  float  *faElvOut = *pfaElvOut;

//
// Initialize the arrays to the default data.
//
  for ( i=0; i < *lpMaxInOut; i++ ) {
    laAptIdntOut[i] = BLANK_4;
    laRwyIdntOut[i] = BLANK_4;
    daLatOut[i]     = 0.0;
    daLonOut[i]     = 0.0;
    faHdgOut[i]     = 0.0;
    faElvOut[i]     = 0.0;
  }

//
// Open the IP datafile for read purposes. First check to see if it needs to be checked out of RCS.
//  If the file open fails, post an error to the log file.
//
  if ( ( hFp = fopen( szHoldFileName, "r" ) ) == NULL ) {
    fprintf( stderr,"Cannot open Hold Short IP data file '%s' with read permissions", szHoldFileName );
    *lpMaxInOut = 0;
    return;
  }

//
// Read the file into the local arrays. Limit the amount of data read to the input variable *lpMaxInOut.
//
  iCnt = 0;

  while ( fgets( szBuffer, sizeof( szBuffer ), hFp ) && ( iCnt < *lpMaxInOut ) ) {
    if ( szBuffer[0] != '#' && strlen( szBuffer ) > 1 ) {
      i = sscanf( szBuffer, " %d %s %s %lf %lf %f %f\n",
                  &iIdx,tAptIdnt.sz, tRwyIdnt.sz, &dLat, &dLon, &fHdg, &fElv );

      if ( i == 7 ) {                         //Correct number of items
        for ( k=strlen( tAptIdnt.sz ); k<4; k++ ) {
          tAptIdnt.sz[k] = ' ';
        }
        laAptIdntOut[iCnt] = tAptIdnt.l;

        for ( k=strlen( tRwyIdnt.sz ); k<4; k++ ) {
          tRwyIdnt.sz[k] = ' ';
        }
        laRwyIdntOut[iCnt] = tRwyIdnt.l;

        daLatOut[iCnt] = dLat;
        daLonOut[iCnt] = dLon;
        faHdgOut[iCnt] = fHdg;
        faElvOut[iCnt] = fElv;

        iCnt++;
      }
      else {
        fprintf( stderr,"Hold Data Mismatch %s/%s.",
                 tAptIdnt.sz, tRwyIdnt.sz );
      }
    }
    else {
//      fprintf(stderr,"Hold Data Comment Line %10.10s.", szBuffer );
    }
  }

  fclose( hFp );

  fprintf( stderr,"%d Hold ip's read.  %d ip's requested.", iCnt, *lpMaxInOut );

  *lpMaxInOut = i;

  return;
}

///////////////////////////////////////////////////////////////////////
//  n_ip_ramp_write -
//    Write the ramp information and returns the arrays to the host.
///////////////////////////////////////////////////////////////////////

void n_ip_ramp_write( long *lpMaxIn,          char    *szRampFileName,
                      long   **plaAptIdntIn,  long   **plaGateIdIn,
                      double **pdaLatIn,      double **pdaLonIn,
                      float  **pfaHdgIn,      float  **pfaElvIn )
{
  FILE *hFp;
  static char szString[256]="";
  static char szBuffer[1024];
  int  i, iCnt;
  union { char sz[5];
    long l;
  } tAptIdnt;
  union { char sz[5];
    long l;
  } tGateIdnt;

  long lFileLength,lOffset;

  long   *laAptIdntIn = *plaAptIdntIn;
  long   *laGateIdIn  = *plaGateIdIn;
  double *daLatIn     = *pdaLatIn;
  double *daLonIn     = *pdaLonIn;
  float  *faHdgIn     = *pfaHdgIn;
  float  *faElvIn     = *pfaElvIn;

//  Open the IP datafile for write purposes.
//  Check file access for existence and write priveledges.
//  The file must exist writeable, or be checked out locked in
//  order to update the file.  It will NOT be automatically checked out.
//  If the file open fails, set the number read to zero and return to
//  the calling program.
//

  if ( ( hFp = fopen( szRampFileName, "r+" ) ) == NULL ) {
    fprintf( stderr,"Cannot open Ramp IP data file '%s' with read/write permissions, check file permissions",
             szRampFileName );
    *lpMaxIn = 0;
    return;
  }

// Get the file length, and skip past the comment lines before beginning
// to write out the data.
//
  fseek( hFp, 0L, SEEK_END );
  lFileLength = ftell( hFp );
  fseek( hFp, 0L, SEEK_SET );

  lOffset = 0;
  while ( fgets( szBuffer, sizeof( szBuffer )-1, hFp ) ) {
    if ( szBuffer[0] == '#' ) {         //Comment line!
      lOffset = ftell( hFp );           //Start of next line
    }
    else {                              //Non-Comment line
      fseek( hFp, lOffset, SEEK_SET );  //Reset to this line
      break;
    }
  }

//  Write the data arrays out to the data file.
//  Limit the amount of data written to the input variable *lpMaxInOut.
//

  for ( i=0,iCnt=0; i < *lpMaxIn; i++ ) {
    tAptIdnt.l  = laAptIdntIn[i];    //Convert Airport Ident
    tGateIdnt.l = laGateIdIn[i];     //Convert Gate Ident
    if ( tGateIdnt.l == BLANK_4 )  tGateIdnt.l = 0x40404040;

    sprintf( szString, "%4d %4.4s %4.4s %13.8lf %13.8lf %7.3f %7.3f\n",
             i+1, tAptIdnt.sz, tGateIdnt.sz,
             daLatIn[i], daLonIn[i], faHdgIn[i], faElvIn[i] );

    if ( fputs( szString, hFp ) < 0 ) {
      fprintf( stderr,"Error writing to Ramp IP data file '%s' ",
               szRampFileName );
    }
    iCnt++;
  }

// If the new data is shorter than the original data, then there may
// be some left over characters left at the bottom of the file.
// Convert this remaining data to dummy comment lines.
//
  lOffset = ftell( hFp );
  while ( lOffset < lFileLength ) {
    if ( fputs( "###  Dummy Line - Can be removed\n", hFp ) < 0 ) {
      fprintf( stderr,"Error writing to Ramp IP data file '%s' ",
               szRampFileName );
    }
  }

//
// Close the file when completed.
//
  fclose( hFp );

  fprintf( stderr,"%d Ramp ip's written to %s.", i, szRampFileName );

  return;
}

void n_ip_hold_write( long *lpMaxIn,            char    *szHoldFileName,
                      long   **plaAptIdntIn,    long   **plaRwyIdntIn,
                      double **pdaLatIn,        double **pdaLonIn,
                      float  **pfaHdgIn,        float  **pfaElvIn )
{
  FILE *hFp;
  static char szString[256] ="";
  static char szBuffer[1024];
  int  i,iCnt;

  long lFileLength,lOffset;
  union { char sz[5];
    long l;
  } tAptIdnt;
  union { char sz[5];
    long l;
  } tRwyIdnt;

  long   *laAptIdntIn = *plaAptIdntIn;
  long   *laRwyIdntIn = *plaRwyIdntIn;
  double *daLatIn     = *pdaLatIn;
  double *daLonIn     = *pdaLonIn;
  float  *faHdgIn     = *pfaHdgIn;
  float  *faElvIn     = *pfaElvIn;

//  Open the IP datafile for write purposes.
//  Check the file access for existence and write priveledges.
//  The file must have both read/write access, and be checked out.
//  The file will not be automatically checked out.
//  If the file open fails, set the number read to zero and return to
//  the calling program.
//

  if ( ( hFp = fopen( szHoldFileName, "r+" ) ) == NULL ) {
    fprintf( stderr,"Cannot open Hold IP data file '%s' with read/write permissions, check file permissions",
             szHoldFileName );
    *lpMaxIn = 0;
    return;
  }

//  Get the file length, ans skip past the comment lines before
//  beginning to write out the data.
//
  fseek( hFp, 0L, SEEK_END );
  lFileLength = ftell( hFp );
  fseek( hFp, 0L, SEEK_SET );

  lOffset = 0;
  while ( fgets( szBuffer, sizeof( szBuffer )-1, hFp ) ) {
    if ( szBuffer[0] == '#' ) {              //Comment line!
      lOffset = ftell( hFp );                //Start of next line
    }
    else {                                   //Non-Comment line
      fseek( hFp, lOffset, SEEK_SET );       //Start of this line
      break;
    }
  }

//  Write the data arrays out to the data file.
//  Limit the amount of data written to the input variable *lpMaxInOut.
//

  for ( i=0,iCnt=0; i < *lpMaxIn; i++ ) {
    tAptIdnt.l = laAptIdntIn[i];
    tRwyIdnt.l = laRwyIdntIn[i];

    sprintf( szString, " %4d %4.4s %4.4s %13.8lf %13.8lf %7.3f %7.3f\n",
             i+1, tAptIdnt.sz, tRwyIdnt.sz,
             daLatIn[i], daLonIn[i], faHdgIn[i], faElvIn[i] );

    if ( fputs( szString, hFp ) < 0 ) {
      fprintf( stderr,"Error writing to Hold IP data file '%s' ",
               szHoldFileName );
    }
    iCnt++;
  }

// If the new data is shorter than the original data, then there may
// be some left over characters left at the bottom of the file.
// Conver this data to dummy comment lines.
//
  lOffset = ftell( hFp );
  while ( lOffset < lFileLength ) {
    if ( fputs( "###  Dummy Line - Can be removed\n", hFp ) < 0 ) {
      fprintf( stderr,"Error writing to Hold IP data file '%s' ",
               szHoldFileName );
    }
  }

//
// Close the file when completed.
//
  fclose( hFp );
  fprintf( stderr,"%d Hold ip's written to %s.", i, szHoldFileName );
  return;
}

