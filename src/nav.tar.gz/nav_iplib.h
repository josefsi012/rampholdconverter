#ifndef NAV_IPLIB_H_INCLUDED
#define NAV_IPLIB_H_INCLUDED

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h> /* For PATH_MAX */

#define BLANK_4 0x20202020         //4 ASCII blanks

/*/////////////////////////////////////////////////////////////////////
//  n_ip_ramp_read -
//    Reads the ramp information and returns the arrays to the host.
/////////////////////////////////////////////////////////////////////*/

void n_ip_ramp_read( long *lpMaxInOut,       char    *szRampFileName,
                     long   **plaAptIdntOut, long   **plaGateIdOut,
                     double **pdaLatOut,     double **pdaLonOut,
                     float  **pfaHdgOut,     float  **pfaElvOut );


/*/////////////////////////////////////////////////////////////////////
//  n_ip_hold_read -
//    Reads the hold information and returns the arrays to the host.
/////////////////////////////////////////////////////////////////////*/

void n_ip_hold_read( long *lpMaxInOut,        char    *szHoldFileName,
                     long   **plaAptIdntOut,  long   **plaRwyIdntOut,
                     double **pdaLatOut,      double **pdaLonOut,
                     float  **pfaHdgOut,      float  **pfaElvOut );


/*/////////////////////////////////////////////////////////////////////
//  n_ip_ramp_write -
//    Write the ramp information and returns the arrays to the host.
/////////////////////////////////////////////////////////////////////*/

void n_ip_ramp_write( long *lpMaxIn,          char    *szRampFileName,
                      long   **plaAptIdntIn,  long   **plaGateIdIn,
                      double **pdaLatIn,      double **pdaLonIn,
                      float  **pfaHdgIn,      float  **pfaElvIn );


/*/////////////////////////////////////////////////////////////////////
//  n_ip_hold_write -
//    Write the hold information and returns the arrays to the host.
/////////////////////////////////////////////////////////////////////*/

void n_ip_hold_write( long *lpMaxIn,            char    *szHoldFileName,
                      long   **plaAptIdntIn,    long   **plaRwyIdntIn,
                      double **pdaLatIn,        double **pdaLonIn,
                      float  **pfaHdgIn,        float  **pfaElvIn );
#endif // NAV_IPLIB_H_INCLUDED
